﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prog4.Prog5.App_Code
{
    public class shoppingBag
    {
        private string ID;
        private string Name;
        private double uPrice;
        private int qty;
        private double cost;

        public shoppingBag(string id, string prodName, double price, int quantity, double subTotal)
        {
            ID = id;
            Name = prodName;
            uPrice = price;
            qty = quantity;
            cost = subTotal;
        }

        public string getID()
        {
            return ID;
        }

        public string getName()
        {
            return Name;
        }

        public double getPrice()
        {
            return uPrice;
        }

        public int getQty()
        {
            return qty;
        }

        public double getCost()
        {
            return cost;
        }
    }
}