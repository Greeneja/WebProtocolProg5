﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog4
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        private string[] keepIDs = new string[5] { "p101", "p103", "p107", "p109", "p201" };

        private int Prog3_Index
        {
            get
            {
                if (Session["Prog3_Index"] != null)
                {
                    return (int)Session["Prog3_Index"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["Prog3_Index"] = value; }
        }

        private int past_Index
        {
            get
            {
                if (Session["past_Index"] != null)
                {
                    return (int)Session["past_Index"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["past_Index"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //txtMessage.Text = "";
            //if (!IsPostBack)
            //{
            //    DisplayRow(Prog3_Index);
            //}
            //if (Prog3_Index == 0)
            //{
            //    btnFirst.Enabled = false;
            //    btnPrevious.Enabled = false;
            //}
            //else if (Prog3_Index == App_Code.SQLDataClass.tblProduct.Rows.Count - 1)
            //{
            //    btnLast.Enabled = false;
            //    btnNext.Enabled = false;
            //}
        }

        protected void btnFirst_Click(object sender, EventArgs e)
        {
            //Prog3_Index = 0;
            //DisplayRow(Prog3_Index);
            //btnFirst.Enabled = false;
            //btnPrevious.Enabled = false;
            //btnLast.Enabled = true;
            //btnNext.Enabled = true;
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            //int index = Prog3_Index - 1;
            //if (index < 0)
            //{
            //    index = 0;
            //}
            //Prog3_Index = index;
            //DisplayRow(index);
            //btnLast.Enabled = true;
            //btnNext.Enabled = true;
            //if (Prog3_Index == 0)
            //{
            //    btnFirst.Enabled = false;
            //    btnPrevious.Enabled = false;
            //}
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            //int index = Prog3_Index + 1;
            //if (index > App_Code.SQLDataClass.tblProduct.Rows.Count - 1)
            //{
            //    index = App_Code.SQLDataClass.tblProduct.Rows.Count - 1;
            //}
            //Prog3_Index = index;
            //DisplayRow(index);
            //btnFirst.Enabled = true;
            //btnPrevious.Enabled = true;
            //if (Prog3_Index == App_Code.SQLDataClass.tblProduct.Rows.Count - 1)
            //{
            //    btnLast.Enabled = false;
            //    btnNext.Enabled = false;
            //}
        }

        protected void btnLast_Click(object sender, EventArgs e)
        {
            //Prog3_Index = App_Code.SQLDataClass.tblProduct.Rows.Count - 1;
            //DisplayRow(Prog3_Index);
            //btnLast.Enabled = false;
            //btnNext.Enabled = false;
            //btnFirst.Enabled = true;
            //btnPrevious.Enabled = true;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    string theID = txtID.Text;
            //    string newName = txtName.Text;
            //    double newPrice = double.Parse(txtPrice.Text.Replace("$", ""));
            //    string newDesc = txtDescription.Text;
            //    App_Code.SQLDataClass.UpdateProduct(theID, newName, newPrice, newDesc);
            //    txtMessage.Text = "Record updated.";
            //    App_Code.SQLDataClass.getAllProducts();
            //}
            //catch (Exception ex)
            //{
            //    txtMessage.Text = "Product Not Updated: " + ex.Message;
            //}
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //bool deletable = true;
            //if (btnDelete.Text == "Delete")
            //{
            //    try
            //    {
            //        string theID = txtID.Text;
            //        for (int i = 0; i < keepIDs.Count(); i++)
            //        {
            //            if (theID == keepIDs[i])
            //            {
            //                deletable = false;
            //            }
            //        }
            //        if (deletable)
            //        {
            //            App_Code.SQLDataClass.DeleteProduct(theID);
            //            txtMessage.Text = "Record Deleted.";
            //            Prog3_Index = Prog3_Index - 1;
            //            App_Code.SQLDataClass.getAllProducts();
            //            DisplayRow(Prog3_Index);
            //        }
            //        else
            //        {
            //            txtMessage.Text = "Record cannot be Deleted.";
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        txtMessage.Text = "Product Not Deleted: " + ex.Message;
            //    }
            //}
            //else
            //{
            //    Prog3_Index = Prog3_Index - 1;
            //    App_Code.SQLDataClass.getAllProducts();
            //    DisplayRow(Prog3_Index);
            //    btnNew.Text = "New";
            //    btnDelete.Text = "Delete";
            //    btnUpdate.Enabled = true;
            //    btnFirst.Enabled = true;
            //    btnPrevious.Enabled = true;
            //}

        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            //if (btnNew.Text == "New")
            //{
            //    past_Index = Prog3_Index;
            //    Prog3_Index = App_Code.SQLDataClass.tblProduct.Rows.Count;
            //    txtID.Text = "";
            //    txtName.Text = "";
            //    txtPrice.Text = "";
            //    txtDescription.Text = "";
            //    txtMessage.Text = "";
            //    btnFirst.Enabled = false;
            //    btnPrevious.Enabled = false;
            //    btnNext.Enabled = false;
            //    btnLast.Enabled = false;
            //    btnUpdate.Enabled = false;
            //    btnNew.Text = "Save New";
            //    btnDelete.Text = "Cancel";
            //}
            //else
            //{
            //    try
            //    {
            //        for (int i = 0; i < App_Code.SQLDataClass.tblProduct.Rows.Count; i++)
            //        {
            //            TableRow row = new TableRow();
            //            TableCell cell = new TableCell();
            //            if (App_Code.SQLDataClass.tblProduct.Rows[i][0].ToString() == txtID.Text)
            //            {
            //                txtMessage.Text = "ID already exists.";
            //            }
            //        }
            //        if (txtMessage.Text != "ID already exists.")
            //        {
            //            btnNew.Text = "New";
            //            btnDelete.Text = "Delete";
            //            string theID = txtID.Text;
            //            string Name = txtName.Text;
            //            double Price = double.Parse(txtPrice.Text.Replace("$", ""));
            //            string Desc = txtDescription.Text;
            //            App_Code.SQLDataClass.AddProduct(theID, Name, Price, Desc);
            //            btnFirst.Enabled = true;
            //            btnPrevious.Enabled = true;
            //            btnUpdate.Enabled = true;
            //            txtMessage.Text = "Record Added.";
            //            App_Code.SQLDataClass.getAllProducts();
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        txtMessage.Text = "Product Not Added: " + ex.Message;
            //    }
            //}
        }

        private void DisplayRow(int index)
        {
            //DataRow row = App_Code.SQLDataClass.tblProduct.Rows[index];
            //txtID.Text = row[0].ToString();
            //txtName.Text = row[1].ToString();
            //txtPrice.Text = string.Format("{0:C}", row[2]);
            //txtDescription.Text = row[3].ToString();
        }

        protected void DetailsView1_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
        {
            DetailsView1.PageIndex = e.NewPageIndex;
            DetailsView1.DataBind();
        }

        protected void DetailsView1_ItemInserting(object sender, DetailsViewInsertEventArgs e)
        {
            try
            {
                TextBox theID = DetailsView1.Rows[0].Cells[1].Controls[0] as TextBox;
                TextBox Name = DetailsView1.Rows[1].Cells[1].Controls[0] as TextBox;
                TextBox Price = DetailsView1.Rows[2].Cells[1].Controls[0] as TextBox;//double.Parse(DetailsView1.Rows[2].Cells[1].Text);
                TextBox Desc = DetailsView1.Rows[3].Cells[1].Controls[0] as TextBox;
                double newPriceDouble = double.Parse(Price.Text);
                for (int i = 0; i < App_Code.SQLDataClass.tblProduct.Rows.Count; i++)
                {
                    TableRow row = new TableRow();
                    TableCell cell = new TableCell();
                    if (App_Code.SQLDataClass.tblProduct.Rows[i][0].ToString() == theID.Text)
                    {
                        txtMessage.Text = "ID already exists.";
                    }
                }
                if (txtMessage.Text != "ID already exists.")
                {
                    SqlDataSource1.InsertCommand = "insert into Product(ProductID, ProductName, UnitPrice, Description)" +
                        " values ('" + theID.Text + "', '" + Name.Text + "', " + newPriceDouble + ", '" + Desc.Text + "')";
                    //App_Code.SQLDataClass.AddProduct(theID.Text, Name.Text, newPriceDouble, Desc.Text);
                    txtMessage.Text = "Record Added.";
                }
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Added: " + ex.Message;
            }
        }

        protected void DetailsView1_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
        {
            try
            {
                string theID = DetailsView1.Rows[0].Cells[1].Text; //txtID.Text;
                TextBox newName = DetailsView1.Rows[1].Cells[1].Controls[0] as TextBox;
                TextBox newPrice = DetailsView1.Rows[2].Cells[1].Controls[0] as TextBox;//double.Parse(DetailsView1.Rows[2].Cells[1].Text);
                TextBox newDesc = DetailsView1.Rows[3].Cells[1].Controls[0] as TextBox;
                double newPriceDouble = double.Parse(newPrice.Text);
                SqlDataSource1.UpdateCommand = "Update Product " +
                    "Set ProductName = '" + newName.Text + "', " +
                    "UnitPrice = " + newPriceDouble + ", " +
                    "Description = '" + newDesc.Text + "' " +
                    "Where ProductID = '" + theID + "'";
                txtMessage.Text = "Record updated.";
                //App_Code.SQLDataClass.UpdateProduct(theID, newName.Text, newPriceDouble, newDesc.Text);
                //SqlDataSource1.DataBind();
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Updated: " + ex.Message;
            }
        }

        protected void DetailsView1_ItemDeleting(object sender, DetailsViewDeleteEventArgs e)
        {
            bool deletable = true;
            try
            {
                string theID = DetailsView1.Rows[0].Cells[1].Text;
                for (int i = 0; i < keepIDs.Count(); i++)
                {
                    if (theID == keepIDs[i])
                    {
                        deletable = false;
                    }
                }
                if (deletable)
                {
                    SqlDataSource1.DeleteCommand = "Delete From Product " +
                        "Where ProductID ='" + theID + "'";
                    //App_Code.SQLDataClass.DeleteProduct(theID);
                    txtMessage.Text = "Record Deleted.";
                }
                else
                {
                    txtMessage.Text = "Record cannot be Deleted.";
                }
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Deleted: " + ex.Message;
            }
        }
    }
}